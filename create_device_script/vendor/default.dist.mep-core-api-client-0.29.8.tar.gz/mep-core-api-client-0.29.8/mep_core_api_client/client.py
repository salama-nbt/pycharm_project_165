"""
 * Created by yilmaz on 26.02.23.
 * Project: mep-core-api
"""
import json

import httpx

from .configuration import Configuration
from .auth import Auth


def invalidate_session_token_on_401(max_retries=3):
    def decorator(function):
        def wrapper(self, *args, **kwargs):
            retry_counter = 1
            result = function(self, *args, **kwargs)

            # Note: in case there is error from API, not Ory, then we don't need to handle it here.
            error = result.get("error", {})
            if isinstance(error, dict) and error.get("code") == 401 and retry_counter < max_retries:
                retry_counter += 1
                self.session_token = self.authentication.session_token
                result = function(self, *args, **kwargs)

            return result
        return wrapper
    return decorator


class APIClient(object):
    def __init__(self, config: Configuration):
        self.base_path = ""
        self.config = config
        self.authentication = Auth(config)
        self.base_service_url = config.service_url
        self.session_token = self.authentication.session_token

        self.client = httpx.Client(
            verify=config.root_ca_path if config.root_ca_path else False,
            headers={"Authorization": "bearer " + self.session_token}
        )

    def set_base_path(self, base_path: str):
        self.base_path = base_path
        return self

    @property
    def service_url(self):
        return self.base_service_url + self.base_path

    @invalidate_session_token_on_401(max_retries=3)
    def get(self, path: str, params: dict = None):
        """
        get the path with params with httpx.
        Include base path if it is set.
        :param path:
        :param params:
        :return:
        """

        result = self.client.get(self.service_url + path, params=params,
                                 headers={"Authorization": "bearer " + self.session_token,
                                          "Content-Type": "application/json"})
        return result.json()

    @invalidate_session_token_on_401(max_retries=3)
    def post(
        self, path: str, data: dict = None, files: dict = None,
        content_type: str = "application/json"
    ):
        headers = {"Authorization": "bearer " + self.session_token}
        # If content_type == multipart/form-data then httpx will set the content type automatically
        if content_type != "multipart/form-data":
            headers["Content-Type"] = content_type
            data = json.dumps(data, default=str)

        result = self.client.post(
            self.service_url + path,
            data=data,
            files=files,
            headers=headers
        )

        return result.json()

    @invalidate_session_token_on_401(max_retries=3)
    def put(self, path: str, data: dict = None):
        result = self.client.put(self.service_url + path, data=json.dumps(data, default=str),
                                 headers={"Authorization": "bearer " + self.session_token,
                                          "Content-Type": "application/json"})

        return result.json()

    @invalidate_session_token_on_401(max_retries=3)
    def delete(self, path: str, data: dict = None):
        pass

    @invalidate_session_token_on_401(max_retries=3)
    def patch(self, path: str, data: dict = None):
        pass
