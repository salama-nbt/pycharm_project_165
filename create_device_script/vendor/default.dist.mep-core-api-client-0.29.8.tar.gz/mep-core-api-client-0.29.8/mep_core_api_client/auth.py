import httpx
import redis
from datetime import datetime

from .configuration import Configuration


class Auth:
    def __init__(self, config: Configuration):
        self.username = config.username
        self.password = config.password
        self.auth_url = config.auth_url
        self.client = httpx.Client(verify=config.root_ca_path if config.root_ca_path else False)

        if all([config.redis_host, config.redis_port, config.redis_db]):
            self.redis_client = redis.Redis(
                host=config.redis_host, port=config.redis_port, db=config.redis_db)
        else:
            self.redis_client = None

    def get_login(self):
        """
        Use httpx to get login flow from Ory Kratos
        :return:
        """

        response = self.client.get(
            self.auth_url + "/self-service/login/api",
            headers={"Content-Type": "application/json"},
        )
        return response.json()

    def login(self):
        """
        Use httpx to log in to Ory Kratos
        :return:
        """

        login_flow = self.get_login()
        response = self.client.post(
            login_flow["ui"]["action"],
            headers={"Content-Type": "application/json"},
            json={
                "csrf_token": login_flow["ui"]["nodes"][0]["attributes"]["value"],
                "password": self.password,
                "identifier": self.username,
                "method": "password",
            },
        )
        if response.status_code != 200:
            raise Exception("Login failed")
        return response.json()

    @property
    def session_token(self):
        """
        Get session token from login response
        :return:
        """

        if self.redis_client is None:
            login_response = self.login()
            return login_response["session_token"]

        key = "ory_kratos_session_token"
        value = self.redis_client.get(key)

        if value is None:
            login_response = self.login()

            expires_at = login_response["session"]["expires_at"]
            expires_at = expires_at[:26] + "Z"  # convert milliseconds to microseconds
            time_format = "%Y-%m-%dT%H:%M:%S.%fZ"
            expires_at_dt = datetime.strptime(expires_at, time_format)

            timeout = expires_at_dt - datetime.utcnow()

            value = login_response["session_token"]
            self.redis_client.set(key, value, ex=timeout)
        else:
            value = value.decode()

        return value
