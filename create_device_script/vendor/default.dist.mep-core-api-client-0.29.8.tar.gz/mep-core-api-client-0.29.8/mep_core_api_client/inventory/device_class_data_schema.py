from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class DeviceClassDataSchemaValidateArgs:
    device_class_id: str
    version: str
    type: str
    data: dict


class DeviceClassDataSchema:

    def __init__(self, client: APIClient):
        self.client = client

    def validate(self, **kwargs):
        args = DeviceClassDataSchemaValidateArgs(**kwargs)
        data = asdict(args)
        return self.client.post(path="/device_class_data_schemas/validate", data=data)
