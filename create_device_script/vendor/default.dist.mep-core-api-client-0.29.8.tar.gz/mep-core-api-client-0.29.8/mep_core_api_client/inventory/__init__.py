from .firmware import Firmware
from .device import Device
from .device_class_data_schema import DeviceClassDataSchema
from .device_class_config import DeviceClassConfig
from ..client import APIClient


class Inventory:
    def __init__(self, client: APIClient):
        client = client.set_base_path("/inventory")
        self.firmware = Firmware(client)
        self.device = Device(client)
        self.device_class_data_schema = DeviceClassDataSchema(client)
        self.device_class_config = DeviceClassConfig(client)
