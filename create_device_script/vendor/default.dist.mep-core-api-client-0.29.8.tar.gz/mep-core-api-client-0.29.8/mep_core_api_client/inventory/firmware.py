from io import BufferedReader
from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class FirmwareCreateArgs:
    device_class_id: str
    version: str
    description: str = None


class Firmware:

    def __init__(self, client: APIClient):
        self.client = client

    def list_firmwares(self):
        """ List all firmwares """
        return self.client.get(path="/firmwares")

    def get_firmware(self, id):
        return self.client.get(path=f"/firmwares/{id}")

    def get_devices(self, id):
        return self.client.get(path=f"/firmwares/{id}/matching-devices")

    def create_firmware(self, firmware_file: BufferedReader, **kwargs):
        args = FirmwareCreateArgs(**kwargs)
        data = asdict(args)
        return self.client.post(
            path="/firmwares", data=data,
            files={"firmware_file": firmware_file},
            content_type="multipart/form-data"
        )
