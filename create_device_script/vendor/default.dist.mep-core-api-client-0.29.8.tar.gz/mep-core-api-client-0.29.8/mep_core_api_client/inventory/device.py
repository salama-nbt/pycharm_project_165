from datetime import datetime
from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class DeviceCreateArgs:
    device_class_id: str
    device_id: str


@dataclass(kw_only=True)
class DeviceListArgs:
    search: str = None
    is_synced: bool = None
    limit: int = None
    offset: int = None
    device_class_id: int = None


@dataclass(kw_only=True)
class DeviceUpdateArgs:
    is_synced: bool = None
    metadata: dict = None
    state: str = None
    last_message: datetime.now = None
    firmware_status: int = None
    fw_version: str = None


class Device:

    def __init__(self, client: APIClient):
        self.client = client

    def get_device(self, id):
        """ Get device details """
        return self.client.get(path=f"/devices/{id}")

    def list_devices(self, **kwargs):
        """ List / search devices

            args:
            - search (optional): str - search by device id or device name
            - is_synced (optional): bool - filter by is_synced
            - limit (optional): int - limit (default 10)
            - offset (optional): int - limit (default 0)
            - device_class_id (optional): int - filter by device class id (default None)
        """
        args = asdict(DeviceListArgs(**kwargs))
        params = {key: value for key, value in args.items() if value is not None}
        return self.client.get(path="/devices", params=params)

    def update_device(self, id, **kwargs):
        """ Update device

            args:
            - is_synced (optional): bool - update is_synced
            - metadata (optional): dict - update metadata
            - state (optional): str - update state
            - last_message (optional): datetime.now() - update last_message in metadata
            - firmware_status (optional): int - update firmware_status
            - fw_version (optional): str - update fw_version
        """
        # As API restrict PATCH-method, details request need to be made to get all device values
        args = asdict(DeviceUpdateArgs(**kwargs))
        last_message = args.pop("last_message", None)
        params = {key: value for key, value in args.items() if value is not None}

        device_data = self.get_device(id)
        # It there is no device class then device was not found
        device_class = device_data.pop("device_class", None)
        if device_class:
            device_data["device_class_id"] = device_class["pk"]
            device_data.update(params)
            if last_message:
                device_data["metadata"]["last_message"] = last_message

            return self.client.put(path=f"/devices/{id}", data=device_data)

    def get_or_create_device(self, **kwargs):
        """ Get or create device, also during this operation device will be provisioned.

            args:
            - device_class_id: str - device class id
            - device_id: str - device id
        """
        args = DeviceCreateArgs(**kwargs)
        data = asdict(args)
        data["name"] = data["device_id"]

        response = self.client.post(path="/devices", data=data)
        if error := response.get("error"):
            if error.startswith("duplicate key value violates"):
                return True, None
            elif error == "{'device_class': ['Device Class does not exist.']}":
                return False, "Device Class does not exist."

        return True, None

    def provision_device(self, id):
        """Get URLs to download private and public certificate keys for specified device id."""
        response = self.client.get(path=f"/devices/{id}")
        device_class_name = response["device_class"]["name"]
        provision_data = {
            "device_id": id,
            "device_class": device_class_name,
        }
        return self.client.post(path="/devices/provision", data=provision_data)
