from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class DeviceClassConfigCreateArgs:
    device_class_id: str
    config_data: dict
    version: str
    is_default: bool = False


class DeviceClassConfig:

    def __init__(self, client: APIClient):
        self.client = client

    def get_device_class_config(self, device_class_id: str):
        response = self.client.get(
            path="/device_class_configs?sort=-version",
            params={
                "device_class_id": device_class_id,
                "is_default": True
            }
        )
        return response["results"][0] if response["results"] else None

    def create_device_class_config(self, **kwargs):
        args = DeviceClassConfigCreateArgs(**kwargs)
        data = asdict(args)
        return self.client.post(path="/device_class_configs", data=data)
