from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class DataTransferConfigListArgs:
    device_id: str = None
    enabled: bool = True
    hook_type: str = None
    payload_type: str = None
    limit: int = None
    offset: int = None


class DataTransferConfig:

    def __init__(self, client: APIClient):
        self.client = client

    def list_data_transfer_configs(self, **kwargs):
        """ List data transfer configs

            args:
            - device_id (optional): str — filter by Device ID
            - enabled (optional): bool - filter by enabled data transfer config
            - hook_type (optional): str — filter by hook type
            - payload_type (optional): str — filter by payload type
            - limit (optional, default is 10): int — limit the number of results
            - offset (optional, default is 0): int — offset the results
        """
        args = asdict(DataTransferConfigListArgs(**kwargs))
        params = {key: value for key, value in args.items() if value is not None}
        return self.client.get(path="/configs", params=params)
