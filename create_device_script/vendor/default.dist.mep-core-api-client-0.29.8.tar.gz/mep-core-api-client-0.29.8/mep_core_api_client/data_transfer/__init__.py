from .data_transfer_config import DataTransferConfig
from ..client import APIClient


class DataTransfer:
    def __init__(self, client: APIClient):
        client = client.set_base_path("/data-transfer")
        self.data_transfer_config = DataTransferConfig(client)
