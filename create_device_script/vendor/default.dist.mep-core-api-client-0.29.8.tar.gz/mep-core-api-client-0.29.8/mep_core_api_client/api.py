from .configuration import Configuration
from .client import APIClient

from .inventory import Inventory
from .alerting import Alerting
from .data_transfer import DataTransfer
from .data_api import DataAPI


class API:
    def __init__(self, config: Configuration):
        self.client = APIClient(config)

    @property
    def inventory(self):
        return Inventory(client=self.client)

    @property
    def alerting(self):
        return Alerting(client=self.client)

    @property
    def data_transfer(self):
        return DataTransfer(client=self.client)

    @property
    def data_api(self):
        return DataAPI(client=self.client)
