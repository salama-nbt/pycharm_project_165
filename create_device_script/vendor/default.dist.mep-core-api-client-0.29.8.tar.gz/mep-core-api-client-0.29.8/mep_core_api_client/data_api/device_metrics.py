from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class DeviceMetricsArgs:
    time: str = None
    device_id: str
    latest: bool = None

@dataclass(kw_only=True)
class DeviceMetricsExportArgs:
    time: str = None
    device_ids: list[str]


class DeviceMetrics:

    def __init__(self, client: APIClient):
        self.client = client

    def list_device_metrics(self, **kwargs):
        """ List Device Metrics

            args:
            - time (optional): str — time from and to range
            - device_id: str - Device ID
            - latest (optional): bool — latest metric only for device
        """
        args = asdict(DeviceMetricsArgs(**kwargs))
        params = {key: value for key, value in args.items() if value is not None}
        return self.client.get(path="/device_metrics", params=params)

    def export_device_metrics(self, **kwargs):
        """ Export Device Metrics

            args:
            - time (optional): str — time from and to range
            - devices_ids: list[str] — Device IDs
        """
        args = asdict(DeviceMetricsExportArgs(**kwargs))
        params = {key: value for key, value in args.items() if value is not None}
        return self.client.get(path="/device_metrics/export", params=params)