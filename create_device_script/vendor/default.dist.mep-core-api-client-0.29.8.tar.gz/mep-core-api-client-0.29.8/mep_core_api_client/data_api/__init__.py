from .device_metrics import DeviceMetrics
from .device_measurements import DeviceMeasurements
from ..client import APIClient


class DataAPI:
    def __init__(self, client: APIClient):
        client = client.set_base_path("/data-api")
        self.device_metrics = DeviceMetrics(client)
        self.device_measurements = DeviceMeasurements(client)