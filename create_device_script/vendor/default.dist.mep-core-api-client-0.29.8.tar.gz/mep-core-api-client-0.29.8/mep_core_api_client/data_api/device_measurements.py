from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class DeviceMeasurementsArgs:
    time: str = None
    device_id: str
    latest: bool = None

@dataclass(kw_only=True)
class DeviceMeasurementsExportArgs:
    time: str = None
    device_ids: list[str]


class DeviceMeasurements:

    def __init__(self, client: APIClient):
        self.client = client

    def list_device_measurements(self, **kwargs):
        """ List Device Measurements

            args:
            - time (optional): str — time from and to range
            - device_id: str - Device ID
            - latest (optional): bool — latest measurement only for device
        """
        args = asdict(DeviceMeasurementsArgs(**kwargs))
        params = {key: value for key, value in args.items() if value is not None}
        return self.client.get(path="/device_measurements", params=params)

    def export_device_metrics(self, **kwargs):
        """ Export Device Measurements

            args:
            - time (optional): str — time from and to range
            - devices_ids: list[str] — Device IDs
        """
        args = asdict(DeviceMeasurementsExportArgs(**kwargs))
        params = {key: value for key, value in args.items() if value is not None}
        return self.client.get(path="/device_measurements/export", params=params)