from .alert_config import AlertConfig
from .alert_log import AlertLog
from ..client import APIClient


class Alerting:
    def __init__(self, client: APIClient):
        client = client.set_base_path("/alerting")
        self.alert_config = AlertConfig(client)
        self.alert_log = AlertLog(client)
