from dataclasses import dataclass, asdict
from ..client import APIClient


@dataclass(kw_only=True)
class AlertConfigListArgs:
    timeout_configs: bool = None
    device_class: str = None
    device_id: str = None
    enabled: bool = True    # by default only return enabled alert configs
    data_type: str = None
    limit: int = None
    offset: int = None


class AlertConfig:

    def __init__(self, client: APIClient):
        self.client = client

    def list_alert_configs(self, **kwargs):
        """ List alert configs

            args:
            - device_class (optional): int — filter by Device Class
            - timeout_configs (optional): bool - filter by timeout alert config
            - limit (optional, default is 10): int — limit the number of results
            - offset (optional, default is 0): int — offset the results
        """
        args = asdict(AlertConfigListArgs(**kwargs))
        params = {key: value for key, value in args.items() if value is not None}
        return self.client.get(path="/configs", params=params)
