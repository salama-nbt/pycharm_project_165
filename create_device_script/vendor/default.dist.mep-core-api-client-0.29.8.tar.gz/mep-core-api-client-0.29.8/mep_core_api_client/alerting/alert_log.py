from enum import Enum
from dataclasses import dataclass, asdict
from ..client import APIClient


class StateEnum(Enum):
    ON = "ON"
    OFF = "OFF"


@dataclass(kw_only=True)
class AlertLogCreateArgs:
    config: str
    device: str
    state: StateEnum
    data: dict


class AlertLog:

    def __init__(self, client: APIClient):
        self.client = client

    def create_alert_log(self, **kwargs):
        args = AlertLogCreateArgs(**kwargs)
        data = asdict(args)
        return self.client.post(path="/logs", data=data)
