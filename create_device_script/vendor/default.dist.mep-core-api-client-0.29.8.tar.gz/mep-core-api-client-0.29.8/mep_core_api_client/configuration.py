from dataclasses import dataclass


@dataclass(kw_only=True)
class Configuration:
    username: str
    password: str
    auth_url: str
    service_url: str

    root_ca_path: str = None

    redis_host: str = None
    redis_port: int = None
    redis_db: int = None
