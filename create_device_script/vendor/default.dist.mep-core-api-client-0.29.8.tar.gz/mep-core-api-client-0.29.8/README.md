# MEP Core API Python Client
- SDK just exports minimal set of APIs to the user. For more information about the MEP Core API, see the MEP Core API documentation.
- To receive rootCA.pem for root_ca_path follow [these steps](https://github.com/next-big-thing-ag/mep-core#mkcert)
